# Security Plugin — Installation Guide

**Version:** 1.0.0 | **Author:** ATech

Full-stack security bundle for Payload CMS 3.x + Next.js 14+ (App Router).

## What this plugin includes

| Feature | Details |
|---|---|
| Brute-force / login lockout | Tracks failed logins per IP; auto-locks after N attempts |
| Two-Factor Authentication (TOTP) | Google Authenticator / Authy compatible; backup codes included |
| Upload security | MIME type blocklist, extension blocklist, double-extension check, SVG sanitization |
| Full audit log | Logs create/update/delete/login/failed-login/2FA events with user + IP |
| IP allowlist / blocklist | File-backed cache (`data/ip-cache.json`) refreshed on Settings save |
| API rate limiting | In-memory per-IP per-endpoint window counter |
| HTTP security headers | CSP, HSTS, X-Frame-Options, X-Content-Type-Options, Referrer-Policy |
| Security dashboard | `/admin/security` — lockouts, failed logins, audit trail |
| 2FA verification page | `/admin/verify-2fa` — TOTP or backup code entry |

---

## Step 1 — Install npm dependencies

```bash
npm install speakeasy qrcode
npm install -D @types/qrcode
```

---

## Step 2 — Copy plugin files

Copy all files from this archive into your project, keeping the directory structure:

```
src/
├── plugins/
│   ├── securityPlugin.ts             ← main plugin entry
│   └── security/
│       ├── auditLogger.ts            ← logEvent() + buildAuditHooks()
│       ├── headers.ts                ← buildSecurityHeaders() + defaultSecurityHeaders
│       ├── ipFilter.ts               ← IP cache read/write + filter hook
│       ├── loginProtection.ts        ← checkLockout(), recordFailedLogin(), clearLockout()
│       ├── rateLimiter.ts            ← checkRateLimitSync() (in-memory)
│       ├── twoFactor.ts              ← TOTP generate/verify + backup codes
│       └── uploadSecurity.ts         ← validateUpload(), sanitizeSvg(), registerUploadHooks()
├── collections/
│   ├── AuditLogs.ts                  ← audit-logs collection
│   └── SecurityEvents.ts             ← security-events collection
├── components/
│   └── admin/
│       └── SecurityNavLink.tsx       ← sidebar nav link
├── hooks/
│   └── usePluginActive.ts            ← shared hook (skip if already present)
└── app/
    ├── (payload)/
    │   └── admin/
    │       ├── security/
    │       │   └── page.tsx          ← security dashboard (Server Component)
    │       └── verify-2fa/
    │           └── page.tsx          ← 2FA verification screen
    └── api/
        └── security/
            ├── 2fa-setup/
            │   └── route.ts          ← POST /api/security/2fa-setup
            ├── 2fa-verify/
            │   └── route.ts          ← POST /api/security/2fa-verify
            └── unlock-ip/
                └── route.ts          ← POST /api/security/unlock-ip
```

> `src/hooks/usePluginActive.ts` is shared with the SEO Plugin. Copy it only once.

---

## Step 3 — Register the new collections in `payload.config.ts`

```ts
import { AuditLogs } from './collections/AuditLogs'
import { SecurityEvents } from './collections/SecurityEvents'

export default buildConfig({
  collections: [
    // ... your existing collections
    AuditLogs,
    SecurityEvents,
  ],
})
```

---

## Step 4 — Register the plugin in `payload.config.ts`

```ts
import { securityPlugin } from './plugins/securityPlugin'

export default buildConfig({
  plugins: [
    securityPlugin({
      // Collections to attach audit logging to
      auditCollections: ['pages', 'posts', 'portfolio', 'media', 'users', 'job-vacancies'],
    }),
  ],
})
```

---

## Step 5 — Add the admin sidebar nav link

Inside `payload.config.ts → admin.components.afterNavLinks`:

```ts
admin: {
  components: {
    afterNavLinks: [
      '@/components/admin/SecurityNavLink#SecurityNavLink',
    ],
  },
},
```

> The nav link only shows for the admin user. Update the email guard in `SecurityNavLink.tsx` line 12:
> ```tsx
> if ((user as any)?.email !== 'your-admin@email.com') return null
> ```
> Or remove it to show to all logged-in users.

---

## Step 6 — Add HTTP security headers to `next.config.ts`

```ts
import { defaultSecurityHeaders } from './src/plugins/security/headers'

const nextConfig: NextConfig = {
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: defaultSecurityHeaders,
      },
    ]
  },
}
```

This adds: CSP, HSTS, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy.

---

## Step 7 — Add 2FA fields to your Users collection

In your `Users` collection (`src/collections/Users.ts`), add these hidden fields:

```ts
{
  name: 'twoFactorSecret',
  type: 'text',
  hidden: true,
  admin: { hidden: true },
},
{
  name: 'twoFactorBackupCodes',
  type: 'array',
  hidden: true,
  admin: { hidden: true },
  fields: [{ name: 'code', type: 'text' }],
},
{
  name: 'twoFactorEnabled',
  type: 'checkbox',
  label: 'Two-Factor Authentication',
  defaultValue: false,
  admin: {
    description: 'Enable TOTP-based 2FA. Set up via the 2FA setup endpoint after enabling.',
  },
},
```

---

## Step 8 — Add security settings to your Settings global

In your Settings global (`src/globals/Settings.ts`), add a security tab/group:

```ts
{
  label: 'Security',
  fields: [
    {
      name: 'loginMaxAttempts',
      type: 'number',
      label: 'Max Login Attempts Before Lockout',
      defaultValue: 5,
    },
    {
      name: 'loginLockoutMinutes',
      type: 'number',
      label: 'Lockout Duration (minutes)',
      defaultValue: 15,
    },
    {
      name: 'ipFilterEnabled',
      type: 'checkbox',
      label: 'Enable IP Filter',
      defaultValue: false,
      admin: { description: 'Activates allowlist/blocklist enforcement' },
    },
    {
      name: 'ipBlocklist',
      type: 'array',
      label: 'IP Blocklist',
      fields: [
        { name: 'ip', type: 'text', required: true, label: 'IP Address' },
        { name: 'reason', type: 'text', label: 'Reason (optional)' },
      ],
    },
    {
      name: 'ipAllowlist',
      type: 'array',
      label: 'IP Allowlist',
      admin: { description: 'If non-empty, only these IPs can access the admin panel' },
      fields: [
        { name: 'ip', type: 'text', required: true, label: 'IP Address' },
      ],
    },
  ],
},
```

---

## Step 9 — Ensure the `data/` directory exists

The IP filter writes a live cache file at `data/ip-cache.json`. Make sure the directory exists and is writable by the Node process:

```bash
mkdir -p data
```

On a production server, this directory must persist across deploys (same as your `data/payload.db`).

---

## Step 10 — Run database migration

After adding the two new collections (`AuditLogs`, `SecurityEvents`) and the new fields to `Users`, run Payload's migration tool:

```bash
npm run migrate
```

---

## Step 11 — Verify

1. Start the dev server: `npm run dev`
2. Navigate to `/admin/security` — the Security Dashboard should load with empty stat cards
3. Try logging in with wrong credentials 5× — the 6th attempt should return a lockout error
4. Go to **Settings → Security** in admin — set lockout values and save; changes apply immediately
5. Upload a `.exe` or `.php` file to Media — it should be rejected with an error message
6. Go to `/admin/collections/audit-logs` — all create/update/delete events should be logged with IP

### Testing 2FA (optional)

1. Call `POST /api/security/2fa-setup` (authenticated) — returns a QR code data URL and backup codes
2. Scan the QR in Google Authenticator or Authy
3. Call `POST /api/security/2fa-verify` with `{ "token": "123456" }`
4. On success, a `2fa-verified` cookie is set (8-hour TTL)

---

## File reference

| File | Purpose |
|---|---|
| `securityPlugin.ts` | Main plugin — registers all sub-module hooks on `onInit` |
| `security/auditLogger.ts` | `logEvent()` writes to `audit-logs`; `buildAuditHooks()` attaches to collections |
| `security/headers.ts` | `defaultSecurityHeaders` export for `next.config.ts` |
| `security/ipFilter.ts` | Reads/writes `data/ip-cache.json`; registers afterChange hook on Settings |
| `security/loginProtection.ts` | `checkLockout()`, `recordFailedLogin()`, `clearLockout()` using `security-events` |
| `security/rateLimiter.ts` | In-memory sliding window rate limiter (`checkRateLimitSync()`) |
| `security/twoFactor.ts` | TOTP secret generation, token verification, backup code hashing |
| `security/uploadSecurity.ts` | MIME + extension blocklist, double-extension check, SVG sanitizer |
| `AuditLogs.ts` | Payload collection — admin-only read, no create/update from UI |
| `SecurityEvents.ts` | Payload collection — tracks lockouts, rate-limit hits, blocked uploads |
| `SecurityNavLink.tsx` | Admin sidebar link to `/admin/security` |
| `usePluginActive.ts` | Checks `plugins` collection for active status (30 s cache) |
| `admin/security/page.tsx` | Server Component — Security Dashboard with stats, lockouts, audit trail |
| `admin/verify-2fa/page.tsx` | Client Component — 2FA code entry screen |
| `api/security/2fa-setup/route.ts` | POST — generates TOTP secret + QR + backup codes |
| `api/security/2fa-verify/route.ts` | POST — verifies TOTP token or backup code, sets cookie |
| `api/security/unlock-ip/route.ts` | POST — admin-only, clears a lockout for a given IP |
