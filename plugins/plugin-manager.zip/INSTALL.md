# Plugin Manager — Installation Guide

**Version:** 1.0.0 | **Author:** ATech

A full admin UI for managing Payload CMS plugins: activate/deactivate toggles, create/edit/delete, frontend script injection, and a sidebar nav link. Structured as a reusable drop-in, like the Layout Builder plugin.

## What this package includes

| File | Purpose |
|---|---|
| `src/app/(payload)/admin/plugins-activation/page.tsx` | Plugin Manager admin page — card grid, toggle, drawer, delete dialog |
| `src/components/admin/PluginNavLink.tsx` | Sidebar nav link to `/admin/plugins-activation` |
| `src/components/admin/SlugField.tsx` | Auto-generating slug field (used in the `plugins` collection) |
| `src/hooks/usePluginActive.ts` | Client hook — checks if a named plugin is active (30 s cache) |

> **Not included:** the `plugins` collection. You must create it separately (see Step 2).  
> The Plugin Manager is the admin UI on top of that collection — it is not the collection itself.

---

## Prerequisites

- Payload CMS 3.x
- Next.js 14+ (App Router)
- A `users` collection with a `role` field (`'admin'` | `'editor'`)

---

## Step 1 — Copy plugin files

Copy all files from this archive into your project, keeping the directory structure:

```
src/
├── app/
│   └── (payload)/
│       └── admin/
│           └── plugins-activation/
│               └── page.tsx          ← Plugin Manager admin page
├── components/
│   └── admin/
│       ├── PluginNavLink.tsx         ← sidebar nav link
│       └── SlugField.tsx             ← slug field component
└── hooks/
    └── usePluginActive.ts            ← shared active-check hook
```

> `src/hooks/usePluginActive.ts` is shared with the SEO and Security plugins. If you have already installed either, skip copying it.

---

## Step 2 — Create the `plugins` collection

> **Skip this step if you installed the SEO Plugin, Security Plugin, or any other ATech plugin** — they all self-seed into this collection, which means the collection is already required. The Plugin Manager is just the UI on top of it.

Create `src/collections/Plugins.ts` with at minimum these fields (the Plugin Manager page reads and writes all of them):

```ts
import type { CollectionConfig } from 'payload'

export const Plugins: CollectionConfig = {
  slug: 'plugins',
  admin: {
    useAsTitle: 'name',
    defaultColumns: ['name', 'pluginType', 'status', 'version', 'updatedAt'],
    group: 'System',
    hidden: true,   // hides from default sidebar; Plugin Manager is the entry point
  },
  access: {
    read:   ({ req }) => Boolean(req.user),
    create: ({ req }) => req.user?.role === 'admin',
    update: ({ req }) => req.user?.role === 'admin',
    delete: ({ req }) => req.user?.role === 'admin',
  },
  fields: [
    { name: 'name',        type: 'text',     required: true },
    {
      name: 'slug',
      type: 'text',
      required: true,
      unique: true,
      admin: {
        components: {
          Field: '@/components/admin/SlugField#SlugField',
        },
        custom: { watchField: 'name', urlPrefix: '/plugins/' },
      },
    },
    { name: 'description', type: 'textarea' },
    {
      name: 'pluginType',
      type: 'select',
      defaultValue: 'utility',
      options: [
        { label: 'Built-in',           value: 'built-in' },
        { label: 'Frontend Script',    value: 'frontend-script' },
        { label: 'Block Extension',    value: 'block-extension' },
        { label: 'Third-party Embed',  value: 'third-party-embed' },
        { label: 'Integration',        value: 'integration' },
        { label: 'Utility',            value: 'utility' },
      ],
    },
    {
      name: 'category',
      type: 'select',
      defaultValue: 'utility',
      options: [
        { label: 'Layout',    value: 'layout' },
        { label: 'Content',   value: 'content' },
        { label: 'Media',     value: 'media' },
        { label: 'Analytics', value: 'analytics' },
        { label: 'SEO',       value: 'seo' },
        { label: 'Ecommerce', value: 'ecommerce' },
        { label: 'Utility',   value: 'utility' },
      ],
    },
    {
      name: 'status',
      type: 'select',
      required: true,
      defaultValue: 'inactive',
      options: [
        { label: 'Active',   value: 'active' },
        { label: 'Inactive', value: 'inactive' },
      ],
    },
    { name: 'version',      type: 'text' },
    { name: 'author',       type: 'text' },
    { name: 'icon',         type: 'upload', relationTo: 'media' },
    {
      name: 'scriptCode',
      type: 'textarea',
      admin: {
        condition: (data) =>
          data.pluginType === 'frontend-script' || data.pluginType === 'third-party-embed',
      },
    },
    { name: 'settings',     type: 'json' },
    {
      name: 'features',
      type: 'array',
      fields: [
        { name: 'featureName',        type: 'text', required: true },
        { name: 'featureDescription', type: 'text' },
        {
          name: 'featureType',
          type: 'select',
          options: [
            { label: 'Collection', value: 'collection' },
            { label: 'Field',      value: 'field' },
            { label: 'Hook',       value: 'hook' },
            { label: 'Script',     value: 'script' },
          ],
        },
      ],
    },
    { name: 'autoActivate', type: 'checkbox', defaultValue: false },
  ],
}
```

Register it in `payload.config.ts`:

```ts
import { Plugins } from './collections/Plugins'

export default buildConfig({
  collections: [
    // ... your existing collections
    Plugins,
  ],
})
```

---

## Step 3 — Add the nav link to the admin sidebar

In `payload.config.ts → admin.components.afterNavLinks`:

```ts
admin: {
  components: {
    afterNavLinks: [
      '@/components/admin/PluginNavLink#PluginNavLink',
    ],
  },
},
```

> The nav link only shows for the admin user. Update the email guard in `PluginNavLink.tsx` line 10:
> ```tsx
> if ((user as any)?.email !== 'your-admin@email.com') return null
> ```
> Or remove it to show to all logged-in users:
> ```tsx
> if (!user) return null
> ```

---

## Step 4 — Add the `getActivePlugins` helper

The Plugin Manager also enables **frontend script injection** — plugins with type `frontend-script` or `third-party-embed` have their `scriptCode` injected into every page. This requires a data-fetching helper.

Add this function to your Payload helper module (e.g. `src/lib/payload.ts`):

```ts
import { unstable_cache } from 'next/cache'

export const getActivePlugins = unstable_cache(
  async () => {
    try {
      const payload = await getPayloadClient()   // your existing getPayload helper
      const result = await payload.find({
        collection: 'plugins',
        where: { status: { equals: 'active' } },
        limit: 100,
      })
      return result.docs
    } catch {
      return []
    }
  },
  ['active-plugins'],
  { tags: ['plugins'] },
)
```

> Replace `getPayloadClient()` with however you initialise Payload in your project (e.g. `getPayload({ config })` or `getPayloadHMR({ config })`).

---

## Step 5 — Wire script injection into your frontend layout

In your root frontend layout (`src/app/(frontend)/layout.tsx` or equivalent), fetch active plugins and inject `scriptCode` into `<head>`:

```tsx
import { getActivePlugins } from '@/lib/payload'   // adjust import path

export default async function FrontendLayout({ children }: { children: React.ReactNode }) {
  const plugins = await getActivePlugins()

  const scriptPlugins = plugins.filter(
    (p: any) =>
      ['frontend-script', 'third-party-embed'].includes(p.pluginType) &&
      typeof p.scriptCode === 'string' &&
      p.scriptCode.trim() !== '',
  )

  return (
    <html>
      <head>
        {/* ... your existing head content */}

        {/* Plugin script injection */}
        {scriptPlugins.map((p: any) => (
          <script key={p.id} dangerouslySetInnerHTML={{ __html: p.scriptCode }} />
        ))}
      </head>
      <body>
        {children}
      </body>
    </html>
  )
}
```

This makes any `frontend-script` or `third-party-embed` plugin's code run on every frontend page. Toggling the plugin's status in the Plugin Manager activates or removes the injection in real-time (Next.js cache is tagged `plugins` and revalidated on change).

---

## Step 6 — Run database migration

After creating the `plugins` collection, run Payload's migration to add the table to your database:

```bash
npm run migrate
```

---

## Step 7 — Verify

1. Start the dev server: `npm run dev`
2. Navigate to `/admin` — you should see a **Plugins** link in the sidebar
3. Click it — the Plugin Manager dashboard loads with stat cards (Total / Active / Inactive)
4. Click **Add Plugin** — the drawer slides in; fill in Name, Type, Status and save
5. Create a `frontend-script` plugin with `scriptCode = "console.log('plugin loaded')"` and set it **Active**
6. Open your frontend in the browser and check the console — the message should appear
7. Deactivate the plugin in Plugin Manager — reload the frontend and the console log should be gone

---

## How `usePluginActive` works (for other plugins)

The `usePluginActive(slug)` hook is used by other plugin nav links (SEO, Security, Backup) to show or hide themselves based on whether their corresponding `plugins` collection record is active.

```tsx
import { usePluginActive } from '@/hooks/usePluginActive'

// Returns: true = active, false = inactive, null = loading
const isActive = usePluginActive('seo')
if (!isActive) return null
```

It polls `/api/plugins?where[slug][equals]=<slug>&where[status][equals]=active` with a 30 s in-memory cache per slug.

---

## File reference

| File | Purpose |
|---|---|
| `admin/plugins-activation/page.tsx` | Full Plugin Manager Client Component — card grid, activate/deactivate toggle, slide-in create/edit drawer, delete confirmation dialog, toast notifications |
| `components/admin/PluginNavLink.tsx` | Sidebar link to `/admin/plugins-activation` — email-guarded, active-state aware |
| `components/admin/SlugField.tsx` | Auto-slug field component with manual/auto toggle, URL preview bar, and copy button — used in the `plugins` collection's slug field |
| `hooks/usePluginActive.ts` | Client hook — fetches active status for a named plugin slug with a 30 s TTL cache |
