# SEO Plugin — Installation Guide

**Version:** 1.0.0 | **Author:** ATech

Traditional SEO + LLM SEO in one bundle for Payload CMS 3.x + Next.js 14+ (App Router).

## What this plugin includes

| Feature | Route / Location |
|---|---|
| Meta title, description, OG fields | Added to each collection via `buildSeoFields()` |
| AI "Generate" button in admin | `src/components/admin/SeoGenerateButton.tsx` |
| SEO nav link in admin sidebar | `src/components/admin/SeoNavLink.tsx` |
| JSON-LD structured data helpers | `src/plugins/seo/jsonld.ts` |
| Dynamic sitemap | `src/app/sitemap.ts` (uses Payload data) |
| Dynamic robots.txt | `src/app/robots.ts` (uses Settings global) |
| `llms.txt` for AI crawlers | `src/app/llms.txt/route.ts` |
| AI content auto-generation | `src/app/api/seo/generate/route.ts` |

---

## Step 1 — Install npm dependencies

```bash
npm install @anthropic-ai/sdk
```

> Skip this if you do not want AI content generation. The plugin works without it — the Generate button returns a 503 when `ANTHROPIC_API_KEY` is not set.

---

## Step 2 — Copy plugin files

Copy all files from this archive into your project, keeping the directory structure:

```
src/
├── plugins/
│   ├── seoPlugin.ts                  ← main plugin entry
│   └── seo/
│       ├── fields.ts                 ← buildSeoFields() helper
│       ├── generateSeoContent.ts     ← Anthropic-powered content generator
│       ├── jsonld.ts                 ← JSON-LD / structured data builder
│       └── llmstxt.ts               ← llms.txt formatter
├── components/
│   └── admin/
│       ├── SeoGenerateButton.tsx     ← "✨ Generate" button in admin fields
│       └── SeoNavLink.tsx            ← sidebar nav link (admin panel)
├── hooks/
│   └── usePluginActive.ts            ← shared hook (skip if already present)
└── app/
    ├── api/
    │   └── seo/
    │       └── generate/
    │           └── route.ts          ← POST /api/seo/generate
    └── llms.txt/
        └── route.ts                  ← GET /llms.txt
```

> `src/hooks/usePluginActive.ts` is shared with the Security Plugin. If you install both, copy it only once.

---

## Step 3 — Add SEO fields to your collections

In each collection that should have SEO tabs (e.g. `Pages.ts`, `Posts.ts`, `Portfolio.ts`):

```ts
import { buildSeoFields } from '@/plugins/seo/fields'

export const Pages: CollectionConfig = {
  // ...
  fields: [
    // ... your existing fields
    buildSeoFields('pages'),   // pass the collection slug
  ],
}
```

Repeat for every collection you want covered (e.g. `'posts'`, `'portfolio'`, `'job-vacancies'`).

---

## Step 4 — Register the plugin in `payload.config.ts`

```ts
import { seoPlugin } from './plugins/seoPlugin'

export default buildConfig({
  plugins: [
    seoPlugin({
      // Collections that get AI auto-fill on first create (optional)
      collections: ['pages', 'posts', 'portfolio', 'job-vacancies'],
    }),
  ],
})
```

---

## Step 5 — Add the admin sidebar nav link

Inside `payload.config.ts → admin.components.afterNavLinks`:

```ts
admin: {
  components: {
    afterNavLinks: [
      '@/components/admin/SeoNavLink#SeoNavLink',
    ],
  },
},
```

> The nav link only shows for the admin user. Update the email guard in `SeoNavLink.tsx` line 13:
> ```tsx
> if ((user as any)?.email !== 'your-admin@email.com') return null
> ```
> Or remove the guard entirely to show to all logged-in users.

---

## Step 6 — Add SEO-related fields to your Settings global

The sitemap, robots.txt, and llms.txt all read from your `settings` global. Add these fields:

```ts
// src/globals/Settings.ts  (or wherever your Settings global is defined)
{
  label: 'SEO & Discovery',
  fields: [
    {
      name: 'canonicalDomain',
      type: 'text',
      label: 'Canonical Domain',
      admin: { description: 'e.g. https://yourdomain.com — used in sitemap and JSON-LD' },
    },
    {
      name: 'siteName',
      type: 'text',
      label: 'Site Name',
    },
    {
      name: 'siteDescription',
      type: 'textarea',
      label: 'Site Description',
    },
    {
      name: 'llmsTxtEnabled',
      type: 'checkbox',
      label: 'Enable llms.txt',
      defaultValue: true,
      admin: { description: 'Exposes /llms.txt for AI crawlers (ChatGPT, Perplexity, Claude)' },
    },
    {
      name: 'robotsDisallow',
      type: 'array',
      label: 'Robots Disallow Paths',
      fields: [{ name: 'path', type: 'text', required: true }],
      admin: { description: 'Additional paths to block in robots.txt (e.g. /private)' },
    },
    {
      name: 'crawlDelay',
      type: 'number',
      label: 'Crawl Delay (seconds)',
      admin: { description: 'Leave blank for no crawl delay' },
    },
  ],
},
```

---

## Step 7 — Add sitemap and robots.txt routes

If you don't already have these, create them in your app root:

**`src/app/sitemap.ts`** — query your collections and call `MetadataRoute.Sitemap`. Uses `settings.canonicalDomain` as the base URL. Refer to the Next.js docs for the full format; the plugin does not bundle these files as they are project-specific.

**`src/app/robots.ts`** — reads `settings.robotsDisallow` and `settings.crawlDelay` from your Settings global.

Minimal example (`src/app/robots.ts`):

```ts
import type { MetadataRoute } from 'next'

export default function robots(): MetadataRoute.Robots {
  return {
    rules: { userAgent: '*', allow: '/', disallow: ['/admin', '/api'] },
    sitemap: 'https://yourdomain.com/sitemap.xml',
  }
}
```

The `llms.txt` route (`src/app/llms.txt/route.ts`) is included in this archive and reads `seo.llmsEntry` from all published documents automatically — no additional config needed.

---

## Step 8 — Set environment variables

Add to your `.env` (and to your deployment secrets):

```env
# Required for AI content generation (Generate button + auto-fill on create)
ANTHROPIC_API_KEY=sk-ant-...
```

---

## Step 9 — Run database migration

The plugin self-seeds a record into your `plugins` collection on first start — no manual migration needed for the plugin itself. However, if you added new fields to existing collections (Step 3), run:

```bash
npm run migrate
```

---

## Step 10 — Verify

1. Start the dev server: `npm run dev`
2. Open any Page or Post in `/admin` — you should see an **SEO** tab with meta title, description, OG fields, and AI & LLM fields
3. Click **✨ Generate** next to any SEO field (save the document first — generation requires a document ID)
4. Visit `/llms.txt` — should list all published content
5. Visit `/sitemap.xml` — should list all published pages
6. Create a new page and save — if `ANTHROPIC_API_KEY` is set, SEO fields auto-fill within ~5 seconds

---

## File reference

| File | Purpose |
|---|---|
| `seoPlugin.ts` | Main plugin — self-seeds, registers afterChange hook for AI auto-fill |
| `seo/fields.ts` | `buildSeoFields(slug)` — returns the SEO tab field group for any collection |
| `seo/generateSeoContent.ts` | Anthropic Claude API call + humanizer post-processor |
| `seo/jsonld.ts` | `buildJsonLd()` — generates JSON-LD schema for Article, WebPage, JobPosting, CreativeWork |
| `seo/llmstxt.ts` | `formatLlmsTxt()` — formats llms.txt from sections of entries |
| `SeoGenerateButton.tsx` | Client component — calls `/api/seo/generate` and fills the field |
| `SeoNavLink.tsx` | Admin sidebar link to SEO Settings |
| `usePluginActive.ts` | Checks `plugins` collection for active status (30s cache) |
| `app/api/seo/generate/route.ts` | POST endpoint — validates request, calls `generateSeoContent()` |
| `app/llms.txt/route.ts` | GET `/llms.txt` — queries all published docs and formats output |
