# Search Plugin

Reusable Payload CMS plugin that wraps `@payloadcms/plugin-search` and
auto-seeds itself into the **Plugin Manager** (`plugins` collection) on first
server start.

## What it creates
- **`search-results`** collection — indexed search documents queryable by keyword
- Auto-indexing hooks that update the index on document create/update/delete

## Installation

```bash
npm install @payloadcms/plugin-search
```

Copy `src/plugins/searchPlugin.ts` into your project, then:

```ts
// payload.config.ts
import { searchPlugin } from '@/plugins/searchPlugin'

export default buildConfig({
  plugins: [
    searchPlugin({
      collections: ['posts', 'pages'],
      defaultPriorities: { posts: 10, pages: 20 },
    }),
  ],
})
```

## Querying search results

```ts
// GET /api/search-results?where[title][like]=<term>
const res = await fetch('/api/search-results?where[title][like]=hello')
const { docs } = await res.json()
```

## Options
| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `slug` | string | `'search'` | Plugin identifier in the Plugins collection |
| `name` | string | `'Search'` | Display name |
| `version` | string | `'1.0.0'` | Version string |
| `author` | string | `'ATech'` | Author name |
| `description` | string | — | Description shown in Plugin Manager |
| `collections` | string[] | `['posts','pages']` | Collections to index |
| `defaultPriorities` | object | `{posts:10,pages:20}` | Search priority per collection |
| `searchOverrides` | object | adds `excerpt` field | Extend the search collection's field definitions |

## Version
1.0.0
