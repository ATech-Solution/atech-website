# Form Builder Plugin

Reusable Payload CMS plugin that wraps `@payloadcms/plugin-form-builder` and
auto-seeds itself into the **Plugin Manager** (`plugins` collection) on first
server start.

## What it creates
- **`forms`** collection — drag-and-drop form builder
- **`formSubmissions`** collection — stores submission data per field

## Installation

```bash
npm install @payloadcms/plugin-form-builder
```

Copy `src/plugins/formBuilderPlugin.ts` into your project, then:

```ts
// payload.config.ts
import { formBuilderPlugin } from '@/plugins/formBuilderPlugin'

export default buildConfig({
  plugins: [
    formBuilderPlugin({
      defaultToEmail: process.env.ADMIN_EMAIL ?? 'admin@example.com',
    }),
  ],
})
```

## Options
| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `slug` | string | `'form-builder'` | Plugin identifier in the Plugins collection |
| `name` | string | `'Form Builder'` | Display name |
| `version` | string | `'1.0.0'` | Version string |
| `author` | string | `'ATech'` | Author name |
| `description` | string | — | Description shown in Plugin Manager |
| `defaultToEmail` | string | `ADMIN_EMAIL` env | Admin email for form submission notifications |
| `fields` | object | see source | Toggle individual field types |

## Version
1.0.0
