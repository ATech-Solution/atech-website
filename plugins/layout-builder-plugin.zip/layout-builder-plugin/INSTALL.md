# Layout Builder Plugin — Installation Guide

A visual drag-and-drop page builder for [Payload CMS](https://payloadcms.com) with infinite-nesting block canvas, reusable block library, and per-block style overrides.

---

## Requirements

| Dependency | Version |
|---|---|
| Payload CMS | `^3.0.0` |
| Next.js | `^14.0.0` |
| React | `^18.0.0` |

---

## Step 1 — Copy the source files

Copy the contents of this zip into your project, preserving the directory structure:

```
your-project/
├── src/
│   ├── plugins/
│   │   └── layoutBuilderPlugin.ts      ← plugin entry
│   ├── collections/
│   │   ├── Blocks.ts                   ← Blocks collection (required)
│   │   └── Plugins.ts                  ← Plugins collection (required)
│   └── components/
│       ├── LayoutBuilder/              ← admin UI components
│       │   ├── LayoutBuilderField.tsx
│       │   ├── BlockCanvas.tsx
│       │   ├── BlockSidebar.tsx
│       │   ├── BlockPicker.tsx
│       │   ├── BlockPropertiesPanel.tsx
│       │   ├── BlockRow.tsx
│       │   ├── BlockListItem.tsx
│       │   ├── BlockListView.tsx
│       │   ├── FloatingPanel.tsx
│       │   ├── LayoutBuilderFullScreen.tsx
│       │   ├── LayoutPreview.tsx
│       │   ├── LayoutBuilder.css
│       │   ├── types.ts
│       │   ├── fields/
│       │   │   ├── AdvancedFields.tsx
│       │   │   ├── BlockStyleFields.tsx
│       │   │   ├── ContentFields.tsx
│       │   │   └── StyleFields.tsx
│       │   └── utils/
│       │       ├── defaultOverrides.ts
│       │       ├── mergeBlock.ts
│       │       ├── previewResolver.tsx
│       │       ├── treeOps.ts
│       │       └── uuid.ts
│       └── block/
│           └── Advance/                ← renderable section components
│               └── *.tsx
```

---

## Step 2 — Register the collections

Add both collections to your Payload config:

```ts
// payload.config.ts
import { Blocks }  from '@/collections/Blocks'
import { Plugins } from '@/collections/Plugins'

export default buildConfig({
  collections: [
    // ...your existing collections
    Blocks,
    Plugins,
  ],
})
```

---

## Step 3 — Register the plugin

```ts
// payload.config.ts
import { layoutBuilderPlugin } from '@/plugins/layoutBuilderPlugin'

export default buildConfig({
  collections: [ Blocks, Plugins, /* ... */ ],
  plugins: [
    layoutBuilderPlugin({
      // All options are optional — defaults shown below
      slug:        'layout-builder',   // unique slug in the Plugins collection
      name:        'Layout Builder Plugin',
      version:     '1.0.0',
      author:      'Your Company',
      description: 'Visual drag-and-drop page builder.',
      // Add extra features beyond the two built-in ones (optional)
      extraFeatures: [
        {
          featureName:        'My Custom Block',
          featureDescription: 'A custom block extension',
          featureType:        'field',
        },
      ],
    }),
  ],
})
```

---

## Step 4 — Add the layoutBuilder field to your Pages collection

```ts
// src/collections/Pages.ts
import type { CollectionConfig } from 'payload'

export const Pages: CollectionConfig = {
  slug: 'pages',
  fields: [
    // ...your other fields
    {
      name: 'layoutBuilder',
      type: 'json',
      label: 'Layout Builder',
      admin: {
        components: {
          Field: '@/components/LayoutBuilder/LayoutBuilderField#LayoutBuilderField',
        },
      },
    },
  ],
}
```

---

## Step 5 — Render the layout on the frontend

Read the `layoutBuilder` JSON field from your page document and render each block:

```tsx
// src/app/(frontend)/[slug]/page.tsx
import { resolvePreview } from '@/components/LayoutBuilder/utils/previewResolver'

export default async function Page({ params }) {
  const page = await getPageBySlug(params.slug) // your data-fetch helper

  return (
    <main>
      {page.layoutBuilder?.map((block, i) => {
        const Component = resolvePreview(block.blockType)
        return Component ? <Component key={i} block={block} /> : null
      })}
    </main>
  )
}
```

---

## Step 6 — Fix the language / default-value import in Blocks.ts (if needed)

`Blocks.ts` ships with optional `defaultValue` helpers that pull from
`@/components/language/home.json`. If that file does not exist in your project,
remove or replace the import at the top of `Blocks.ts`:

```ts
// Remove this line if you don't have the language file:
// import homeEn from '@/components/language/home.json'
// const h = homeEn.home
```

Then remove any `defaultValue: h.<field>` references in the fields below it,
or replace them with your own string literals.

---

## Folder conventions

| Path | Purpose |
|---|---|
| `src/components/LayoutBuilder/` | Payload admin field UI (client components) |
| `src/components/block/Advance/` | Renderable section components (frontend) |
| `src/collections/Blocks.ts` | Reusable block template library (Payload collection) |
| `src/collections/Plugins.ts` | Plugin registry (Payload collection) |
| `src/plugins/layoutBuilderPlugin.ts` | Plugin bootstrap / self-registration |

---

## Block types

The builder ships with three tiers of block types:

- **Basic** — Container, Grid, Heading, Text Editor, Image, Video, Button, Divider, Spacer, Google Map, Icon
- **General** — Tabs, Accordion, Image Box, Icon Box, Image Carousel, Gallery, Icon List, Counter, Progress Bar, Testimonial, Social Icons, Alert, HTML
- **Advance** — Pre-built full-page section components (Hero, Features, Services, Testimonials, Portfolio, Articles, FAQ, etc.)

---

## Troubleshooting

**Plugin seed fails on build** — The plugin skips seeding during `NEXT_PHASE=phase-production-build` automatically.

**`plugins` collection not found** — Make sure `Plugins` is in your `collections` array in `payload.config.ts`.

**Blocks collection not found** — Make sure `Blocks` is also in your `collections` array.

**`@payloadcms/ui` import error** — The LayoutBuilder components are Payload admin client components. Ensure your `tsconfig.json` aliases (`@/`) are configured correctly.
