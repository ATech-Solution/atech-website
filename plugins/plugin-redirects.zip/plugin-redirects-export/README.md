# Redirects Plugin

Reusable Payload CMS plugin that wraps `@payloadcms/plugin-redirects` and
auto-seeds itself into the **Plugin Manager** (`plugins` collection) on first
server start.

## What it creates
- **`redirects`** collection — map old URLs to new destinations (301/302)

## Installation

```bash
npm install @payloadcms/plugin-redirects
```

Copy `src/plugins/redirectsPlugin.ts` into your project, then:

```ts
// payload.config.ts
import { redirectsPlugin } from '@/plugins/redirectsPlugin'

export default buildConfig({
  plugins: [
    redirectsPlugin({ collections: ['pages', 'posts'] }),
  ],
})
```

## Next.js middleware integration

In your `middleware.ts`, query the Payload REST API:

```ts
const res = await fetch(`${process.env.PAYLOAD_URL}/api/redirects?where[from][equals]=${pathname}`)
const { docs } = await res.json()
if (docs[0]) {
  return NextResponse.redirect(new URL(docs[0].to.url, request.url), docs[0].type ?? 301)
}
```

## Options
| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `slug` | string | `'redirects'` | Plugin identifier in the Plugins collection |
| `name` | string | `'Redirects'` | Display name |
| `version` | string | `'1.0.0'` | Version string |
| `author` | string | `'ATech'` | Author name |
| `description` | string | — | Description shown in Plugin Manager |
| `collections` | string[] | `['pages','posts']` | Collections that get a redirects relationship field |

## Version
1.0.0
